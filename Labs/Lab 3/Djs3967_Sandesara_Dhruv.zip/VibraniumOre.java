//Name: Dhruv Sandesara
//EID: djs3967

public class VibraniumOre {
    
    private int price;
    private int weight;
    private int volume;

    public VibraniumOre(int price, int weight, int volume) {

        this.price = price;
        this.weight = weight;
        this.volume = volume;
    }

    public int getPrice() {
    
        return price;
    }

    public int getWeight() {

        return weight;
    }

    public int getVolume() {

        return volume;
    }
}
